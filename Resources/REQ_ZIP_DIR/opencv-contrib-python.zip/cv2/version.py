opencv_version = "4.5.4.60"
contrib = True
headless = False
ci_build = True