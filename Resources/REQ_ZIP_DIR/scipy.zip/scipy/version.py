
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '1.7.3'
version = '1.7.3'
full_version = '1.7.3'
git_revision = '59e6539'
commit_count = '1290'
release = True

if not release:
    version = full_version
